using System;
using MonoDevelop.Components.Commands;
using MonoDevelop.Ide;
using MonoDevelop.Ide.Gui;  
using MonoDevelop.Ide.Gui.Content;
using System.Net.Sockets;
using System.Text;
using System.Net;  

namespace MonoDevelop.UnityInterpreter
{
	 enum UnityInterpreterCommands
	 {
		RunCode
	 }
	
     class RunCodeHandler : CommandHandler  
     {
         private void ExecuteCode(string code)
         {
             try
             {
                 TcpClient client = new TcpClient();
                 client.Connect(IPAddress.Loopback, 50001);
                 byte[] bytes = Encoding.UTF8.GetBytes(code);
                 client.GetStream().Write(bytes, 0, bytes.Length);
                 client.Close();
                 MonoDevelop.Core.LoggingService.Log(MonoDevelop.Core.Logging.LogLevel.Debug,
                     "Executed code on unity interpreter");
             }
             catch (Exception e)
             {
                 MonoDevelop.Core.LoggingService.Log(MonoDevelop.Core.Logging.LogLevel.Warn,
                     "Could not execute code : " + e.Message);
             }
         }
         protected override void Run ()  
         {  
			 IEditableTextBuffer buf = IdeApp.Workbench.ActiveDocument.GetContent<IEditableTextBuffer> ();

             string selectedCode = buf.SelectedText;
             if (string.IsNullOrEmpty(selectedCode))
             {
                 selectedCode = buf.Text;
             }

             ExecuteCode(selectedCode);

         }  
          
         protected override void Update (CommandInfo info)  
         {  
             Document doc = IdeApp.Workbench.ActiveDocument;
		     info.Enabled = doc != null && doc.GetContent<IEditableTextBuffer> () != null;
         }     
     }  
}

